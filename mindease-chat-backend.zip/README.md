# MindEase Chat Backend (Vercel)

Serverless-backend för MindEase-chatten. Streamar svar via SSE från OpenAI Chat Completions.
Har även demo-läge om ingen OPENAI_API_KEY är satt.

## 1) Deploy på Vercel
1. Skapa ett nytt GitHub-repo och lägg in dessa filer (samma struktur).
2. På vercel.com: **New Project → Import** ditt repo.
3. I **Settings → Environment Variables**, lägg till:
   - `OPENAI_API_KEY` = din OpenAI-nyckel (börjar med sk-)
   - `OPENAI_MODEL` = gpt-4o-mini (valfritt)
4. Deploy → du får t.ex.:
   - https://<project>.vercel.app/api/chat
   - https://<project>.vercel.app/api/chat/health

## 2) Testa
curl -N -X POST "https://<project>.vercel.app/api/chat" -H "Content-Type: application/json" -d '{"message":"Hej!"}'

## 3) Koppla Base44
I Base44 (frontend): sätt `CHAT_API_URL` till din /api/chat-URL.
