// api/chat.ts
import type { VercelRequest, VercelResponse } from '@vercel/node';

const KEY = process.env.OPENAI_API_KEY || '';
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  // @ts-ignore
  res.flushHeaders?.();

  const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
  const message: string = (body?.message ?? '').toString();
  const history = Array.isArray(body?.history) ? body.history.slice(-10) : [];
  const mode: string = (body?.mode ?? 'coach').toString();

  const systemPrompt =
    `You are MindEase, a warm, trauma-informed AI coach. Offer supportive reflection, ` +
    `motivational interviewing and brief CBT reframes. Do not diagnose or give medical advice. ` +
    `If crisis indicators appear, show a short empathetic message and encourage contacting local emergency services. ` +
    (mode === 'cbt'
      ? 'Use short CBT steps: Situation → Thought → Feeling → Evidence → Alternative Thought → Action.'
      : mode === 'reflection'
      ? 'Ask one gentle reflective question at a time.'
      : '');

  if (!KEY) {
    const demo =
      `(Demo) Du sa: “${message}”. Här kommer ett varmt, stöttande svar ` +
      `och en kort kognitiv omtolkning (CBT). Prova att koppla upp en riktig nyckel ` +
      `för live-AI.`;
    for (const word of demo.split(' ')) {
      res.write(`data: ${word}\n\n`);
      await sleep(25);
    }
    return res.end('data: [DONE]\n\n');
  }

  try {
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: MODEL,
        stream: true,
        temperature: 0.7,
        messages: [
          { role: 'system', content: systemPrompt },
          ...history,
          { role: 'user', content: message }
        ]
      })
    });

    if (!r.ok || !r.body) {
      const detail = await r.text().catch(() => '');
      res.write(`data: [ERROR] upstream not ok ${detail.slice(0, 200)}\n\n`);
      return res.end('data: [DONE]\n\n');
    }

    const reader = (r.body as any).getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      res.write(decoder.decode(value));
    }
    res.end();
  } catch (e: any) {
    res.write(`data: [ERROR] ${e?.message ?? 'unknown'}\n\n`);
    res.end('data: [DONE]\n\n');
  }
}
